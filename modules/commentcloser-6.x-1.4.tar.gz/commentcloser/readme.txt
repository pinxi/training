Automatically close (set to read-only) comments on node types of your choosing.

comment_closer.module: automatically closes comments on node types of your choice.
-- needs cron
-- runs once daily, weekly, monthly or annually to close comments more than a week, month or year old
-- no table changes or additions, just drop it in your modules directory, enable it, and change
   the settings to your preference.